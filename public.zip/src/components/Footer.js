function Footer(){
  return (
    <div>
    <div className="container">
    
<footer className="py-3 my-4" >
  <ul className="nav justify-content-center border-bottom pb-3 mb-3">
    <li className="nav-item"><a href="#" class="nav-link px-2 text-body-Light">Home</a></li>
    <li className="nav-item"><a href="#" class="nav-link px-2 text-body-Light">List</a></li>
    <li className="nav-item"><a href="#" class="nav-link px-2 text-body-Light">Add</a></li>
    
  </ul>
  <div data-testid="footer-content">
  <p className="text-center text-body-Light">© 2024 APP StrictMode</p>
  </div>
</footer>
</div>

    </div>

  )
}


export default Footer;



